export default function HelpPage() {
  return (
    <div className="size-screen flex flex-col items-center justify-center">
      <div className="text-4xl">Help under construction.</div>
    </div>
  )
}
